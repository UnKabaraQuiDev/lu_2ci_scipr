
import java.awt.Graphics;
import java.util.ArrayList;

public class Game {

    private Player player;
    private Missile missile = null;
    private ArrayList<Invader> alInvaders = new ArrayList<>();

    public Game(int width, int height) {
        for (int i = 0; i < 10; i++) {
            int x = (int) (Math.random() * (width - 29));
            int y = (int) (Math.random() * (height / 2 - 29));
            alInvaders.add(new Invader(x, y));
        }

        player = new Player(0, height - 30);
    }

    public void draw(Graphics g) {
        for (int i = 0; i <= alInvaders.size(); i++) {
            alInvaders.get(i).draw(g);
        }

        player.draw(g);
        if (missile != null) {
            missile.draw(g);
        }
    }

    public void move(int width, int height) {

        for (int i = 0; i < alInvaders.size(); i++) {
            alInvaders.get(i).move(width, height);
        }

        if (missile != null) {
            missile.move();
            if (missile.y + missile.height < 0) {
                missile = null;
            }
        }

        // test if missile hits an invader
        int i = alInvaders.size() - 1;
        while (missile != null && i >= 0) {
            Invader invader = alInvaders.get(i);
            if (missile.intersects(invader)) {
                alInvaders.remove(i);
                missile = null;
            } else {
                i--;
            }
        }
        // Alternative avec une boucle for
        if (missile != null) {
            for (int j = alInvaders.size() - 1; j >= 0; j--) {
                Invader invader = alInvaders.get(j);
                if (missile.intersects(invader)) {
                    alInvaders.remove(j);
                    missile = null;
                    j = -1;
                }
            }
        }
    }

    public void setPlayer(int x, int width) {
        if (x <= width - 30) {
            player.x = x;
        }
    }

    public boolean isOver() {
        return alInvaders.isEmpty();
    }

    public void launchMissile() {
        if (missile == null) {
            missile = new Missile(player.x + player.width / 2 - 2, player.y);
        }
    }
}

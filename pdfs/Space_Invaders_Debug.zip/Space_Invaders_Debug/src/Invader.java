
import java.awt.Color;
import java.awt.Graphics;

public class Invader extends MovingObject {

    public Invader(int x, int y) {
        super(x, y, 30, 30, Color.GREEN);
        setdX((int) (Math.random() * 5) - 2);
        setdY((int) (Math.random() * 5) - 2);
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
        g.setColor(Color.BLACK);
        g.drawLine(x, y, x + width, y + height);
        g.drawLine(x, y + height, x + width, y);
    }

    @Override
    public void move(int pWidth, int pHeight) {
        move(); // ou super.move();
        if (x < 0 || x + width > pWidth) {
            setdX(-getdX());
        }
        if (y < 0 || y + height > 0.75 * pHeight) {
            setdY(-getdY());
        }
    }
}

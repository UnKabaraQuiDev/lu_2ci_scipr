
import java.awt.Color;
import java.awt.Graphics;

public class Missile extends MovingObject {

    public Missile(int x, int y) {
        super(x, y, 5, 10, Color.YELLOW);
        setdX(0);
        setdY(-3);
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
        g.setColor(Color.RED);
        g.drawLine(x, y + height, x + width / 2, y + height + 5);
        g.drawLine(x + width / 2, y + height + 5, x + width, y + height);
    }
}

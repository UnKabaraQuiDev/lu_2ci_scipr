/**
 *
 * @Code de l'examen: 
 */

public class Player {
   
}

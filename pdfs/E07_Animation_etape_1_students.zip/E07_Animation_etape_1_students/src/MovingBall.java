
import java.awt.Graphics;



public class MovingBall {

    private int x = 30;
    private int y = 30;
    private int radius = 30;
    private int xStep = 5;

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getRadius() {
        return radius;
    }

    public int getXStep() {
        return xStep;
    }

    public void doStep(int width) {

    }

    public void draw(Graphics g) {
       
    }
}

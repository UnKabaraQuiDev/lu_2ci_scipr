import java.util.ArrayList;

public class Students
{
	private ArrayList<Student> alStudents = new ArrayList<>();

	public int getRandomNumber(int min, int max) {
		return (int)(Math.random()*(max-min+1))+min;
	}

	public Students(int n) {
		for(int i = 0; i < n; i++) {
			alStudents.add(new Student("Student" + i, getRandomNumber(1, 60)));
		}
	}

	public double getAverageMark() {
		int sum = 0;
		for(int i = 0; i < alStudents.size(); i++) {
			sum += alStudents.get(i).getMark();
		}
		return (double)sum / alStudents.size();
	}

	public int getBestMarkV1() {
		int max = 0;
		for(int i = 0; i < alStudents.size(); i++) {
			if(alStudents.get(i).getMark() > max) {
				max = alStudents.get(i).getMark();
			}
		}
		return max;
	}

	public int getBestMarkV2() {
		int max = alStudents.get(0).getMark();
		for(int i = 1; i < alStudents.size(); i++) {
			if(alStudents.get(i).getMark() > max) {
				max = alStudents.get(i).getMark();
			}
		}
		return max;
	}

	public int getBestMarkV3() {
		if(alStudents.isEmpty()) {
			return -1;
		}
		
		int max = alStudents.get(0).getMark();
		for(int i = 1; i < alStudents.size(); i++) {
			if(alStudents.get(i).getMark() > max) {
				max = alStudents.get(i).getMark();
			}
		}
		return max;
	}

	public int getWorstMark() {
		if(alStudents.isEmpty()) {
			return -1;
		}
		
		int min = alStudents.get(0).getMark();
		for(int i = 1; i < alStudents.size(); i++) {
			if(alStudents.get(i).getMark() < min) {
				min = alStudents.get(i).getMark();
			}
		}
		return min;
	}

	public Student getBestStudent() {
		if(alStudents.isEmpty()) {
			return null;
		}
		
		Student bestStudent = alStudents.get(0);
		for(int i = 1; i < alStudents.size(); i++) {
			if(alStudents.get(i).getMark() > bestStudent.getMark()) {
				bestStudent = alStudents.get(i);
			}
		}
		return bestStudent;
	}

	public int getNthBestMarkV1(int n) {
		ArrayList<Student> alStudentsCopy = new ArrayList<>(alStudents);
		
		for(int i = n - 1; i > 0; i--) {
			alStudents.remove(getBestStudent());
		}
		
		int nthBestMark = getBestMarkV3();

		alStudents = new ArrayList<>(alStudentsCopy);
		
		return nthBestMark;
	}

	// Sorts the students according to their marks 
	// in descending order (best to worst mark).
	// Used algorithm: Selection sort
	public void sortBestToWorst() {
		for(int i = 0; i < alStudents.size() - 1; i++) {
			int bestStudentLocation = i;
			for(int j = i+1; j < alStudents.size(); j++) {
				if(alStudents.get(j).getMark() > alStudents.get(bestStudentLocation).getMark()) {
					bestStudentLocation = j;
				}
			}

			if(bestStudentLocation != i) {
				// Swap students
				Student temp = alStudents.get(bestStudentLocation);
				alStudents.set(bestStudentLocation, alStudents.get(i));
				alStudents.set(i, temp);
			}
		}
	}

	public int getNthBestMarkV2(int n) {
		sortBestToWorst();
		return alStudents.get(n - 1).getMark();
	}

	public int getNthBestMarkV3(int n) {
		//sortBestToWorst(); Better: Move to constructor

		if(n < 1 || n > alStudents.size()) {
			return -1;
		}
		
		return alStudents.get(n - 1).getMark();
	}
}
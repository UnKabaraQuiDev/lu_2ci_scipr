/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author loegu
 */
public class CryptoBox {

    private int[][] C = {{-3, 5, 6},
                         {-1, 2, 2},
                         {1, -1, -1}
                        };
    private int[][] invC = {{0, 1, 2},
                            {-1, 3, 0},
                            {1, -2, 1}
                           };

    // appends spaces to the given string to get a string length of n 
    public String padString(String string, int n) {
        int currentLength = string.length();
        int paddingLength = (n - (currentLength % n)) % n;
        StringBuilder paddedString = new StringBuilder(string);
        for (int i = 0; i < paddingLength; i++) {
            paddedString.append(" ");
        }
        return paddedString.toString();
    }
    
    public int[][] multiply(int[][] A, int[][] B) {
        

        return null;
    }
    
    public String encodeMessage(String textToEncode) {
        
        return null;
    }

    public String decodeMessage(String encodedMessage) {
       
        
        return null;
    }

    

    

}
